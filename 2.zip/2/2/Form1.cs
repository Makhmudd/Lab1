﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2
{
    public partial class Form1 : Form
    {
        int dir1 = 2;
        int dir2 = -1;
        int score = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            button1.Location = new Point(trackBar1.Value*2, button1.Location.Y);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int a = label1.Location.X;
            int b = label1.Location.Y;
            

            int btn1 = button1.Location.X;
            int btn2 = btn1 + 75;

            if (a == 270)
            {
                dir1 *= -1;
            }
            if (b == 0)
            {
                dir2 *= -1;
            }
            if (a == 0)
            {
                dir1 *= -1;
            }
            if (b == 215 && a >= btn1 && a <= btn2)
            {
                dir2 *= -1;
                score++;
            }
            if (b == 280)
            {
                dir1 = 0;
                dir2 = 0;
            }


            a += dir1;
            b += dir2;

            label1.Location = new Point(a, b);
            label2.Text = score.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
